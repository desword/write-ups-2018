# pnghs

Usage: pnghs.exe input-file output-file data-file

## how to build

1. install haskell stack
2. stack setup
3. stack build
